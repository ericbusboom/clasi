---
name: software-engineering
description: Instructions for the software engineering process using brief, use cases, architecture, tickets, and ticket plans
---

# Software Engineering Process

This project follows a structured software engineering workflow. All planning
artifacts live in `.clasi/`.

## Issues vs Tickets

Two distinct concepts govern how work is tracked:

- An **issue** is a proposed change to the system — an idea, bug report,
  enhancement request, or task captured before sprint planning. Issues live
  in `clasi/issues/`. They are the raw material that sprint planning draws
  from. A single issue may spawn one or more tickets, or be deferred
  indefinitely.

- A **ticket** is a concrete implementation step within a sprint. Tickets
  live in `clasi/sprints/<sprint-id>/tickets/`. A ticket is derived from
  (and often closes) an issue, but it is scoped to what can be done in a
  single sprint and carries acceptance criteria, a plan, and a status that
  the SE process enforces.

In short: issues propose; tickets implement.

## Agents

Seven specialized agents drive this process, orchestrated by the
project-manager:

- **project-manager** — Top-level orchestrator. Delegates to the other
  agents, tracks project state, and coordinates sprints and ticket execution.
  Does not implement code or write documents itself.
- **product-manager** — Guides project initiation interviews. Takes a
  stakeholder narration and produces the project overview document.
- **requirements-analyst** — Elicits detailed requirements from stakeholder
  narratives. Produces the brief and use cases for complex projects.
- **architect** — Maintains the system architecture. Writes the sprint's
  Architecture section (in `sprint.md`) each sprint, sized to the change.
  Two modes: initial architecture and sprint update. See
  `instructions/architectural-quality.md` for quality criteria. (In the
  current three-agent model this responsibility is folded into the
  **sprint-planner** agent; see the `architecture-authoring` skill.)
- **technical-lead** — Breaks the sprint architecture into sequenced, numbered
  tickets. Creates ticket plans before implementation begins.
- **architecture-reviewer** — Reviews sprint plans and architecture updates
  for consistency, quality, and risk. Evaluates against the architectural
  quality guide. Produces verdicts with Design Quality Assessment.
- **code-reviewer** — Reviews code changes during ticket execution for
  quality, standards compliance, and security. Produces pass/fail verdicts.

Supporting agents used during implementation:
- **python-expert** — Implements Python code during ticket execution.
- **documentation-expert** — Updates documentation during ticket execution.

## Skills

Reusable workflows that correspond to each stage:

- **project-initiation** — New project: spec → overview, specification, use cases (via project-manager)
- **create-tickets** — Stage 2: architecture → numbered tickets
- **execute-ticket** — Stage 3: ticket → plan → implement → test → done
- **project-status** — Anytime: scan artifacts and report progress
- **plan-sprint** — Plan and set up a new sprint
- **close-sprint** — Validate and close a completed sprint

Supporting skills used during ticket execution:

- **python-code-review** — Code review against coding standards and security
- **generate-documentation** — Create or update project documentation
- **tdd-cycle** — Optional red-green-refactor TDD workflow for implementation
- **systematic-debugging** — Structured four-phase debugging protocol with attempt cap

## Artifacts

### 1. Project Overview (`.clasi/design/overview.md`) — Recommended

A single lightweight document created at project start. Replaces the separate
brief, use cases, and technical plan files for new projects. Detailed planning
lives in sprints.

Contents:
- Project name
- Problem statement (what problem, who has it)
- Target users
- Key constraints (timeline, technology, budget)
- High-level requirements (key scenarios)
- Technology stack
- Sprint roadmap (rough plan of sprints)
- Out of scope

### 2. Architecture (`docs/architecture/`)

Each sprint's `sprint.md` contains an Architecture section, sized to the
change. This section is a **planning-time artifact**: the sprint-planner
authors it at the front of sprint planning, before any tickets are
created. It captures the structural intent for that sprint — what
components change, what design decisions are being made, and why.
Per-sprint Architecture sections accumulate as a chronological historical
record; they are never merged back into canonical design documents. Code
is the source of truth for current architecture; the per-sprint sections
are the record of structural intent over time. Canonical design documents
(`design/overview.md`, etc.) are project-initiation artifacts, frozen
after the project is initiated.

(Sprints planned before the single-doc rewrite — sprints 001-017 — carry
this content in a separate `architecture-update.md` file in the sprint
directory instead of a `sprint.md` section. Both forms coexist; read
whichever exists for a given sprint.)

The optional `docs/architecture/` directory holds **consolidated** architecture
documents produced by the `consolidate-architecture` skill. These merge
multiple sprints' Architecture sections into a single coherent view. They
are distinct from the per-sprint sections and are not required for every
project:

```
docs/architecture/
  architecture-014.md   # Consolidated architecture through sprint 014
  architecture-015.md   # Consolidated architecture through sprint 015
  ...
```

The sprint-planner produces each sprint's Architecture section and
performs its self-review during sprint planning (or records the review as
`skipped` for a trivial/small sprint). See
`instructions/architectural-quality.md` for document structure and quality
criteria.

Not every sprint requires architectural changes -- pure bug fixes and
refactors within existing boundaries can note "N/A — trivial" in the
sprint's Architecture section.

### Legacy: Brief, Use Cases, Technical Plan

For existing projects that predate the overview document, these separate
top-level files remain valid:

- **Brief** (`.clasi/brief.md`) — One-page project description.
- **Use Cases** (`.clasi/usecases.md`) — Enumerated use cases (UC-001, etc.)
  with actor, preconditions, main flow, postconditions, acceptance criteria.
- **Technical Plan** (`.clasi/technical-plan.md`) — Architecture, tech stack,
  component design, data model, APIs, deployment, security.

New projects should use the single `.clasi/design/overview.md` instead
of the three separate top-level files.

### Diagrams in Architecture Documents

Use Mermaid diagrams in architecture documents when they clarify structure
that is hard to convey in text alone. Diagrams should show the target state
at the end of the sprint.

**When to use diagrams:**
- Subsystem/component interaction diagrams (flowchart or C4-style)
- Module dependency diagrams showing how packages relate
- Data flow diagrams for complex pipelines

**When NOT to use diagrams:**
- Swim lane / sequence diagrams unless multi-system sequencing is involved
- Exhaustive class diagrams (too detailed, go stale quickly)
- Diagrams that merely restate what the text already says

**Best practices:**
- Keep diagrams small: 5-10 nodes maximum
- Use Mermaid syntax (renders in GitHub, VS Code, most markdown viewers)
- Label edges with the relationship (calls, depends-on, produces)
- One diagram per concern; do not overload a single diagram

### 4. Sprints (`clasi/sprints/NNN-slug/`)

Each sprint is a **directory** containing its planning documents and tickets.
Ticket numbering is per-sprint (starts at 001 within each sprint).

Directory structure:
```
clasi/sprints/NNN-slug/
├── sprint.md              # Sprint goals, scope, problem, solution, test
│                          # strategy, and Architecture + Use Cases sections
│                          # (right-sized to the change)
└── tickets/
    ├── 001-first-task.md  # Active ticket
    ├── 002-next-task.md   # Active ticket
    └── done/              # Completed tickets and plans
        └── ...
```

(Sprints planned before the single-doc rewrite — sprints 001-017 — have
separate `usecases.md` and `architecture-update.md` files alongside
`sprint.md` instead. Both forms coexist; new sprints use the single-doc
form above.)

Sprint frontmatter (`sprint.md`):
```yaml
---
id: "NNN"
title: Sprint title
status: planning | active | done
branch: sprint/NNN-slug
use-cases: [UC-XXX, ...]
---
```

Active sprints live in `clasi/sprints/`. Completed sprints live in
`clasi/sprints/done/`.

### 5. Tickets (within sprint: `tickets/NNN-slug.md`)

Numbered implementation tickets broken out from the architecture document.
Tickets are numbered per-sprint starting at 001.

File naming: `001-setup-project-skeleton.md`, `002-add-auth-endpoints.md`, etc.

Each ticket has YAML frontmatter:
```yaml
---
id: "NNN"
title: Short title
status: open | in-progress | done
use-cases: [SUC-001, SUC-002]
depends-on: ["NNN"]
github-issue: ""
issue: ""
completes_issue: true
---
```

Followed by: description, acceptance criteria (checkboxes), and
implementation notes.

**Ticket frontmatter field reference:**

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Per-sprint ticket number (`"001"`, `"002"`, …). |
| `title` | string | Short human-readable title. |
| `status` | string | `open`, `in-progress`, or `done`. |
| `use-cases` | list | Sprint use-case IDs this ticket satisfies. |
| `depends-on` | list | Ticket IDs that must be done before this one starts. |
| `github-issue` | string | Linked GitHub issue number or URL, if any. |
| `issue` | string | Filename of the issue in `clasi/issues/` that this ticket addresses, if any. |
| `completes_issue` | bool or map | Controls whether linked issues are archived when this ticket is moved to done. **Default: `true`** — the issue is archived once all tickets that reference it are done. Set to `false` (scalar) to suppress archival for **all** issues linked to this ticket. Set to a mapping `{filename.md: false}` to suppress archival for specific issues by filename. Use `false` when this ticket only partially addresses a long-lived multi-sprint umbrella issue that should survive the sprint close. |

### 6. Ticket Plans (`tickets/NNN-slug-plan.md`)

Before starting work on a ticket, create a plan file with the same number
and slug, ending in `-plan`. For example, ticket `003-add-auth.md` gets a
plan file `003-add-auth-plan.md`. The plan lives in the same `tickets/`
directory as the ticket.

Every ticket plan must include:
1. **Approach** — How the work will be done, key decisions.
2. **Files to create or modify** — What will be touched.
3. **Testing plan** — What tests will be written, what type (unit, system,
   dev), what verification strategy.
4. **Documentation updates** — What docs need updating when the ticket is
   complete.

A ticket plan without a testing section and a documentation section is
incomplete.

### 7. Issues Directory (`clasi/issues/`)

A lightweight capture area for proposed changes — ideas, bug reports,
enhancements, and tasks. Stakeholders and developers add issues here at any
time, especially when the AI agent is busy with other work.

**Issues vs Tickets** — An issue is a *proposed* change (lives in
`clasi/issues/`). A ticket is a *concrete implementation step* within a
sprint (lives in `clasi/sprints/<id>/tickets/`). Sprint planning converts
relevant issues into tickets; issues that are not yet scheduled remain open.

**File format:**
- One markdown file per idea (descriptive filename, e.g., `versioning.md`).
- Each file has a single level-1 heading (`# Title`) followed by description.

**Lifecycle:**
1. **Capture**: Create a `.md` file in `clasi/issues/` with the idea.
2. **Mine**: During sprint planning, the team-lead scans the issues
   directory and discusses relevant items with the stakeholder.
3. **Consume**: When an issue is incorporated into a sprint, it is closed
   via the MCP tool (frontmatter `status: done`).

### 8. Knowledge Directory (`docs/knowledge/`)

Captures hard-won technical understanding from difficult debugging sessions,
non-obvious fixes, and solutions that required significant trial and error.
Each file records what was broken, what was tried, what worked, why it works,
and actionable guidance for future agents.

This is distinct from reflections: reflections capture process failures (the
agent did something wrong), while knowledge captures technical victories
(the problem was genuinely hard and the solution should be preserved).

Knowledge files use the naming convention `YYYY-MM-DD-slug.md` and include
YAML frontmatter with date, tags, and related tickets. Use the
`project-knowledge` skill (`/se knowledge <description>`) to create entries.

## Workflow

### Project Setup (project-manager, initiation mode)

1. The stakeholder provides a written specification file.
2. Dispatch to **project-manager** (initiation mode) with the spec path.
3. Project-manager processes the spec into structured documents:
   `overview.md`, `specification.md`, and `usecases.md`.
4. **Review gate**: Present the overview to the stakeholder. Wait for
   approval before proceeding. If the stakeholder requests changes, revise
   and re-present.

### Sprints (Default Working Mode)

After Stages 1a and 1b are complete, all work is organized into sprints.
A sprint is a focused batch of work with its own lifecycle, branch, and
ticket set.

**Sprint directories** live in `clasi/sprints/NNN-slug/`. Each sprint
directory contains `sprint.md` (with its Architecture and Use Cases
sections) and a `tickets/` subdirectory (see Artifacts §4 above).

**Sprint lifecycle** (skills: **plan-sprint**, **close-sprint**):
1. Stakeholder describes the next batch of work.
2. Create sprint directory with `sprint.md` (goals, scope, use cases,
   architecture, right-sized to the change) and a `tickets/` subdirectory.
3. Create sprint branch (`sprint/NNN-slug`).
4. **Architecture review**: Delegate to the **architecture-reviewer** to
   validate the plan against the existing codebase and architecture.
5. **Review gate**: Present the sprint plan and architecture review to the
   stakeholder. Wait for approval.
6. Create tickets for the sprint in `tickets/` (Stage 2 below).
7. Execute tickets on the sprint branch (Stage 3 below).
8. When all tickets are done, close the sprint (**close-sprint** skill).
   This is an atomic operation — all steps must be completed together:
   a. Merge the sprint branch to main.
   b. Update sprint status to `done` in `sprint.md` frontmatter.
   c. Move the sprint directory to `clasi/sprints/done/`.
   d. Delete the sprint branch.
   e. Commit the closure.
   **Never merge the branch without also archiving the sprint directory.**

Active sprints live in `clasi/sprints/`. Completed sprints live in
`clasi/sprints/done/`.

### Sprint State Database

A SQLite database at `.clasi/.clasi.db` tracks sprint lifecycle state.
AIs interact with it exclusively through MCP tools — never write to the
database directly.

**Seven-phase lifecycle model:**

```
planning-docs → architecture-review → stakeholder-review → ticketing → executing → closing → done
```

Phase transitions are enforced: `advance_sprint_phase` validates that exit
conditions for the current phase are met before allowing the transition.

**Review gates** (required to advance past certain phases):

| Gate | Required to advance from | Recorded by |
|------|--------------------------|-------------|
| `architecture_review` | `architecture-review` → `stakeholder-review` | `record_gate_result` |
| `stakeholder_approval` | `stakeholder-review` → `ticketing` | `record_gate_result` |

Each gate must be recorded as `passed` before the phase can advance.

**Execution lock:**

Only one sprint can be in the `executing` phase at a time. Before advancing
from `ticketing` to `executing`, the sprint must acquire the execution lock
via `acquire_execution_lock`. The lock is released when the sprint is closed
(`close_sprint` releases it automatically).

**MCP tools for state management:**

- `get_sprint_phase(sprint_id)` — Query current phase, gates, and lock status
- `advance_sprint_phase(sprint_id)` — Move to the next phase (validates conditions)
- `record_gate_result(sprint_id, gate, result, notes?)` — Record a review gate outcome
- `acquire_execution_lock(sprint_id)` — Claim the execution lock
- `release_execution_lock(sprint_id)` — Release the execution lock

**Ticket creation gate enforcement:**

**IMPORTANT: DO NOT create tickets until the sprint reaches the `ticketing`
phase.** The `create_ticket` tool checks the state database and blocks ticket
creation if the sprint is before the `ticketing` phase. This prevents tickets
from being created before architecture and stakeholder reviews are complete.
Always follow the phase order: populate planning docs first, pass architecture
review, pass stakeholder review, then and only then create tickets.

### Stage 2: Ticketing (technical-lead)

Skill: **create-tickets**

1. Break the architecture's Sprint Changes into numbered tickets in dependency order.
2. Ensure every use case is covered by at least one ticket.
3. Ensure every ticket traces to at least one use case.
4. **Review gate**: Present the ticket list to the stakeholder. Walk
   through the sequencing and coverage. Wait for approval before starting
   implementation. If the stakeholder requests changes, revise and re-present.

### Stage 3: Implementation (project-manager coordinates)

Skill: **execute-ticket** (repeated for each ticket)

1. Pick the next `open` ticket whose dependencies are all `done`.
2. Create the ticket plan (`NNN-slug-plan.md`).
3. Set the ticket status to `in-progress` in its YAML frontmatter.
4. Implement the ticket following its plan (python-expert or appropriate
   dev agent).
5. Write tests as specified in the plan.
6. Delegate code review to the **code-reviewer** agent. The reviewer checks
   coding standards, security, test coverage, and acceptance criteria. If
   the review fails, fix the findings and re-review.
7. Update documentation as specified in the plan (documentation-expert).
8. Verify all acceptance criteria are met and check them off (`[x]`).
9. Complete the ticket (see **Completing a Ticket** below).

#### Definition of Done

A ticket is not done until ALL of the following are true:

- [ ] All acceptance criteria in the ticket are met and checked off
- [ ] Tests are written and passing (see `instructions/testing.md`)
- [ ] Code review passed by **code-reviewer** (coding standards, security, test coverage)
- [ ] Documentation updated as specified in the ticket plan
- [ ] Changes committed to git with a message referencing the ticket ID
- [ ] Ticket and plan moved to the sprint's `tickets/done/` directory

Do not mark a ticket done if any item is incomplete. If an item cannot be
satisfied, document why in the ticket before completing.

#### Completing a Ticket

When a ticket satisfies the Definition of Done:

1. Set the ticket's `status` to `done` in its YAML frontmatter.
2. Check off all acceptance criteria (`- [x]`).
3. Commit all changes following `instructions/git-workflow.md`. The commit
   message must reference the ticket ID and sprint number if applicable
   (e.g., `feat: add auth endpoint (#003, sprint 001)`).
4. Move the ticket file to the sprint's `tickets/done/` directory.
5. Move the ticket plan file to the sprint's `tickets/done/` directory.

Active tickets live in the sprint's `tickets/` directory. Completed tickets
live in `tickets/done/`. This separation makes it easy to see at a glance
what work remains (active directory) versus what has been finished (done
directory).

#### Error Recovery

Things go wrong during implementation. Here is what to do.

**Test failures:**
1. Read the error output carefully. Diagnose the root cause.
2. Fix the code (not the test, unless the test is wrong).
3. Re-run the tests. Repeat until all pass.
4. If the failure reveals a flaw in the ticket plan, update the plan.
5. If simple diagnosis does not resolve the failure — especially after
   two consecutive failed fix attempts, or when a previously passing
   test breaks — invoke the `systematic-debugging` skill. This provides
   a structured four-phase protocol (evidence gathering, pattern analysis,
   hypothesis testing, root cause fix) and caps attempts at three before
   requiring stakeholder escalation.

**Plan gaps** (the plan missed something needed for implementation):
1. If the gap is small and local (e.g., a missing helper function), update
   the ticket plan and continue.
2. If the gap is architectural (e.g., a missing component, wrong API design),
   stop implementation. Flag the gap to the architect. Update the architecture
   document first, then update the ticket plan, then resume.

**Ticket too large** (the ticket is taking much longer than expected):
1. Stop and assess what is done vs. what remains.
2. Split the ticket: complete and close the part that is done (with tests).
3. Create a new ticket for the remaining work. Update dependencies so the
   new ticket depends on the closed one.
4. Resume with the new ticket.

**Unresolvable blockers:**
1. If you cannot make progress despite trying the above patterns, stop.
2. Document what you tried and what blocked you in the ticket.
3. Set the ticket status back to `open` (not `in-progress` — it is not
   being actively worked).
4. Escalate to the human: explain the blocker and ask for guidance.

## Exception protocol

Lower agents (programmer and sprint-planner) use the exception protocol to
escalate blocks that cannot be resolved within the agent's own authority.

### Threshold

After **three failed fix attempts** on the same problem, stop. Do not make
a fourth attempt. Call `throw_ticket_exception` to record the block and
hand off to the team-lead.

### Payload schema

The `throw_ticket_exception` MCP tool writes an `exception:` block to the
ticket frontmatter and sets `status: exception`:

```yaml
exception:
  thrown_by: programmer        # "programmer" or "sprint-planner"
  thrown_at: 2026-05-07T14:23:00Z
  attempted: |
    Summary of what was tried across three attempts.
  conflict: |
    Exact description of what blocked progress — architecture decision,
    missing dependency, contradictory requirements, etc.
  surface: internal            # "internal" or "user-visible"
```

### Ticket as carrier

The ticket itself is the exception carrier. Its `status` is set to
`exception`; the `exception:` block records the full context. The ticket is
**not** moved to `done/` — it stays in `tickets/` so the team-lead can
inspect and route it.

### Team-lead routing

When the team-lead sees a ticket with `status: exception`, it chooses one of
the following routing branches:

| `surface` value | Routing |
|-----------------|---------|
| `internal`      | Team-lead resolves autonomously: update architecture or ticket plan, reopen with `reopen_ticket`, then continue. |
| `user-visible`  | Team-lead escalates to the stakeholder: present the conflict and wait for a decision before proceeding. |

### Revision naming convention

When reopening an exception ticket after resolution, add a `## Revision`
section or update the title to indicate what changed. Do not silently
re-execute the same plan that failed.

### Calibration signal

A sprint with more than one or two exception tickets signals a planning
problem. Escalate to the stakeholder for scope review rather than resolving
each exception in isolation.

### Stage 4: Maintenance

1. If a change alters scope, update the brief and affected use cases first.
2. If new work is needed, create new tickets following the numbering
   sequence.

## Directory Layout

```
.clasi/
├── design/
│   └── overview.md              # Project overview (recommended)
├── brief.md                     # Top-level brief (legacy)
├── usecases.md                  # Top-level use cases (legacy)
├── technical-plan.md            # Top-level technical plan (legacy, pre-sprint 016)
docs/
└── architecture/                # Versioned architecture documents
    ├── architecture-014.md      # Architecture at end of sprint 014
    ├── architecture-015.md      # Architecture at end of sprint 015
    └── ...
clasi/
├── issues/                      # Proposed changes (ideas, bugs, enhancements)
│   └── some-idea.md             # One issue per file
├── knowledge/                   # Hard-won technical understanding
│   └── YYYY-MM-DD-slug.md       # One knowledge entry per file
└── sprints/
    ├── 001-mcp-server/          # Active sprint directory
    │   ├── sprint.md            # Sprint goals, scope, notes, plus
    │   │                        # Architecture + Use Cases sections
    │   └── tickets/
    │       ├── 003-add-auth.md      # Active ticket
    │       ├── 003-add-auth-plan.md # Its plan
    │       └── done/                # Completed tickets
    │           ├── 001-setup.md
    │           └── 001-setup-plan.md
    └── done/                    # Completed sprint directories
        └── 000-initial-setup/
            ├── sprint.md
            └── tickets/done/
                └── ...
```

## External Tooling

CLASI manages the SE process. Other operational concerns are handled by
dedicated tools — use them instead of ad hoc commands:

| Concern | Tool | How to learn more |
|---------|------|-------------------|
| Environment config, .env files, secrets, encryption keys | **dotconfig** | `dotconfig agent` or `instructions/dotconfig` |
| Deployments, Docker, databases, remote servers | **rundbat** | `rundbat mcp --help` or `instructions/rundbat` |
| GitHub issues (create, import, close) | **gh CLI** via CLASI MCP tools | `list_github_issues`, `close_github_issue`, `create_github_issue` |

When a project has these tools configured, prefer them over raw commands.
For example: use `dotconfig save` instead of editing files under `config/`
directly; use rundbat MCP tools instead of writing raw `docker run`
commands.

## Rules for AI Assistants

- The **project-manager** is the entry point for new projects. It determines
  current state and delegates to the right agent/skill.
- After initial setup (brief, use cases, architecture), always work within
  a sprint. Use **plan-sprint** to start and **close-sprint** to finish.
- When asked to plan work, produce or update these artifacts rather than
  jumping straight to code.
- When asked to implement, find the next unfinished ticket and work from it.
- Always create a ticket plan before starting implementation.
- A ticket is not done until it satisfies the **Definition of Done** (see
  above): acceptance criteria met, tests passing, code review passed,
  documentation updated, changes committed to git.
- Delegate code review to the **code-reviewer** agent, not self-review.
- Delegate architecture review to the **architecture-reviewer** agent during
  sprint planning.
- Follow `instructions/coding-standards.md` when writing code.
- Follow `instructions/git-workflow.md` when committing changes.
- Follow `instructions/testing.md` when writing tests.
- Follow `instructions/architectural-quality.md` for architecture decisions.
- When a ticket is completed, follow the **Completing a Ticket** steps
  immediately — do not batch completions.
- Do not create new artifacts without updating the existing ones to stay
  consistent.
- If a change alters scope, update the brief and affected use cases first.
- Use the **project-status** skill at any time to check where things stand.
