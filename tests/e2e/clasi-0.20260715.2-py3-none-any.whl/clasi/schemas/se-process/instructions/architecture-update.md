# Architecture Review Skill

Evaluate a sprint's architecture update for consistency with the existing
system, design quality, risks, and completeness. Skippable for
trivial/small sprints -- record the gate result as `skipped` rather than
running the review.

## Process

1. **Read the current architecture** in `docs/clasi/architecture/`.
2. **Read the sprint's architecture update** (the Architecture section of
   the sprint's `sprint.md`).
3. **Explore the codebase** to check alignment between documented and
   actual architecture.
4. **Review against the criteria below.**

Sprints planned before the single-doc rewrite (sprints 001-017) may still
carry this content in a separate `architecture-update.md` file in the
sprint directory -- read that file instead for those sprints.

## Review Criteria

### Version Consistency
- Changes in Sprint Changes section reflected in document body?
- Updated architecture internally consistent?
- Design rationale updated for changed decisions?

### Codebase Alignment
- Does current code match documented architecture?
- If drift exists, does the sprint plan account for it?
- Are proposed changes feasible given actual code state?

### Design Quality
- **Cohesion**: Each component responsible for one concern?
- **Coupling**: Minimal, intentional, no circular dependencies?
- **Boundaries**: Clear, enforceable, narrow interfaces?
- **Dependency health**: No cycles, consistent direction, reasonable fan-out?

### Anti-Pattern Detection
- God component, shotgun surgery, feature envy
- Shared mutable state, circular dependencies
- Leaky abstractions, speculative generality

### Risks
- Data migration issues, breaking changes
- Performance or security implications
- Deployment sequencing concerns

## Verdict

- **APPROVE**: No significant issues.
- **APPROVE WITH CHANGES**: Minor issues addressable during implementation.
- **REVISE**: Significant structural issues that need resolution first.

Guidelines:
- Circular deps, god components, broken interfaces → REVISE
- Single contained anti-pattern → APPROVE WITH CHANGES
- Inconsistencies between Sprint Changes and document body → REVISE
- Missing rationale for significant decisions → APPROVE WITH CHANGES
