---
sprint: "{id}"
status: draft
---
<!-- CLASI: Before changing code or making plans, review the SE process in CLAUDE.md -->

# Architecture Update -- Sprint {id}: {title}

## What Changed

(Describe what components, modules, dependencies, or data model elements
were added, modified, or removed in this sprint.)

## Why

(Explain the motivation for these changes. Reference the sprint goals,
use cases, or TODOs that drove them.)

## Impact on Existing Components

(How do these changes affect the rest of the system? Are there new
dependencies, changed interfaces, or deprecated modules?)

## Migration Concerns

(Data migration, backward compatibility, deployment sequencing -- or
"None" if not applicable.)
